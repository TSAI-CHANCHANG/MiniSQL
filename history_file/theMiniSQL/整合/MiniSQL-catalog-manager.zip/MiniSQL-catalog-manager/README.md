# MiniSQL
A simple DBMS. Homework for Database System Concept.
